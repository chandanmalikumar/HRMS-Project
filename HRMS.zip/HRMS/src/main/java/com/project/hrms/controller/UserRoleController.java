package com.project.hrms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.UserRoleDto;
import com.project.hrms.service.UserRoleService;

@RestController
public class UserRoleController {
	
	
	@Autowired
	UserRoleService userRoleService;
	
	
	@PostMapping("/userRole")
	public ResponseEntity<UserRoleDto> SaveUserRole(@RequestBody UserRoleDto userRoleDto){
		userRoleService.saveUserRole(userRoleDto);
		return new ResponseEntity<>(userRoleDto, HttpStatus.CREATED);
	}
}
