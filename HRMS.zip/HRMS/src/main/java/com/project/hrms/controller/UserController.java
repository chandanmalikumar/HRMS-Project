package com.project.hrms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.UserDto;
import com.project.hrms.service.UserService;

@RestController
public class UserController {
	
	
	@Autowired
	UserService userService;
	
	
	@PostMapping("/user")
	public ResponseEntity<UserDto> SaveUser(@RequestBody UserDto userDto){
		userService.saveUser(userDto);
		return new ResponseEntity<>(userDto, HttpStatus.CREATED);
		
	}
}
