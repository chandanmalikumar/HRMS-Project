package com.project.hrms.entity;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name="roles")
public class UserRole {
	
	@Id
	private int roleId;
	private String roleDescription;
	
	
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleDescription() {
		return roleDescription;
	}
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}
	
	
	@Override
	public String toString() {
		return "UserRole [roleId=" + roleId + ", roleDescription=" + roleDescription + "]";
	}
	
	
	@ManyToMany(targetEntity = User.class, mappedBy = "roles",
			cascade = {CascadeType.DETACH, CascadeType.MERGE, CascadeType.PERSIST, CascadeType.REFRESH})
	private List<User> users;
	
	

}
