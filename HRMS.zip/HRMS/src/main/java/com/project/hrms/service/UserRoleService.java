package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.UserRoleRepository;
import com.project.hrms.dto.UserRoleDto;
import com.project.hrms.entity.UserRole;

@Service
public class UserRoleService {
	
	
	@Autowired
	UserRoleRepository userRoleRepository;

	public void saveUserRole(UserRoleDto userRoleDto) {
		userRoleRepository.save(userRoleDtoToUserRole(userRoleDto));
	}
	
	public UserRole userRoleDtoToUserRole(UserRoleDto userRoleDto) {
		UserRole userRole = new UserRole();
		
		userRole.setRoleId(userRoleDto.getRoleId());
		userRole.setRoleDescription(userRoleDto.getRoleDescription());
		return userRole;
	}
	
	public UserRoleDto userRoleToUserRoleDto(UserRole userRole) {
		UserRoleDto userRoleDto = new UserRoleDto();
		
		userRoleDto.setRoleId(userRole.getRoleId());
		userRoleDto.setRoleDescription(userRole.getRoleDescription());
		return userRoleDto;
	}
}
