package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.EmployeeRepository;
import com.project.hrms.dto.EmployeeDto;
import com.project.hrms.entity.Employee;

@Service
public class EmployeeService {
	
	@Autowired
	EmployeeRepository employeeRepository;
	
	public void saveEmployee(EmployeeDto employeeDto) {
		employeeRepository.save(employeeDtoToEmployee(employeeDto));
	}
	
	
	public Employee employeeDtoToEmployee(EmployeeDto employeeDto) {
		Employee employee = new Employee();
		employee.setEmployeeId(employeeDto.getEmployeeId());
		employee.setEmployeeName(employeeDto.getEmployeeAddress());
		employee.setEmployeeEmail(employeeDto.getEmployeeEmail());
		employee.setEmployeePhone(employeeDto.getEmployeePhone());
		employee.setEmployeeAddress(employeeDto.getEmployeeAddress());
		employee.setEmployeePassword(employeeDto.getEmployeePassword());
		return employee;
	}
	
	public EmployeeDto employeeToEmployeeDto(Employee employee) {
		EmployeeDto employeeDto = new EmployeeDto();
		employeeDto.setEmployeeId(employee.getEmployeeId());
		employeeDto.setEmployeeName(employee.getEmployeeName());
		employeeDto.setEmployeeEmail(employee.getEmployeeEmail());
		employeeDto.setEmployeePhone(employee.getEmployeePhone());
		employeeDto.setEmployeeAddress(employee.getEmployeeAddress());
		employeeDto.setEmployeePassword(employee.getEmployeePassword());
		return employeeDto;
		
	}
}
