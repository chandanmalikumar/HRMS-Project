package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.DepartmentRepository;
import com.project.hrms.dto.DepartmentDto;
import com.project.hrms.entity.Department;


@Service
public class DepartmentService {
	
	@Autowired
	DepartmentRepository departmentRepository;
	
	public void saveDept(DepartmentDto departmentDto) {
		departmentRepository.save(departmentDtoToDepartment(departmentDto));
	}

	
	public Department departmentDtoToDepartment(DepartmentDto departmentDto) {
		Department department = new Department();
		department.setEmployeeId(departmentDto.getEmployeeId());
		department.setDepartmentTitle(departmentDto.getDepartmentTitle());
		return department;
	}
	
	public DepartmentDto departmentToDepartmentDto(Department department) {
		DepartmentDto departmentDto = new DepartmentDto();
		departmentDto.setEmployeeId(department.getEmployeeId());
		departmentDto.setDepartmentTitle(department.getDepartmentTitle());
		return departmentDto;
		
	}
}
