package com.project.hrms.dto;

import javax.persistence.Id;

public class TraningDto {

	@Id
	private String traningTitle;
	private String traningDesc;
	
	
	public String getTraningTitle() {
		return traningTitle;
	}
	public void setTraningTitle(String traningTitle) {
		this.traningTitle = traningTitle;
	}
	public String getTraningDesc() {
		return traningDesc;
	}
	public void setTraningDesc(String traningDesc) {
		this.traningDesc = traningDesc;
	}
	
	
	@Override
	public String toString() {
		return "TraningDto [traningTitle=" + traningTitle + ", traningDesc=" + traningDesc + "]";
	}
	
	
	
}
