package com.project.hrms.dto;

import javax.persistence.Id;

public class UserRoleDto {


	@Id
	private int roleId;
	private String roleDescription;
	
	
	public int getRoleId() {
		return roleId;
	}
	public void setRoleId(int roleId) {
		this.roleId = roleId;
	}
	public String getRoleDescription() {
		return roleDescription;
	}
	public void setRoleDescription(String roleDescription) {
		this.roleDescription = roleDescription;
	}
	
	
	@Override
	public String toString() {
		return "UserRoleDto [roleId=" + roleId + ", roleDescription=" + roleDescription + "]";
	}
	
	
}
