package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.SalaryRepository;
import com.project.hrms.dto.SalaryDto;
import com.project.hrms.entity.Salary;

@Service
public class SalaryService {
	
	
	@Autowired
	SalaryRepository salaryRepository;
	
	public void saveSalary(SalaryDto salaryDto) {
		salaryRepository.save(salaryDtoToSalary(salaryDto));
	}
	
	public Salary salaryDtoToSalary(SalaryDto salaryDto) {
		Salary salary = new Salary();
		salary.setEmployeeId(salaryDto.getEmployeeId());
		salary.setSalaryAmount(salaryDto.getSalaryAmount());
		salary.setBonus(salaryDto.getBonus());
		return salary;
	}
	
	public SalaryDto salaryToSalaryDto(Salary salary) {
		SalaryDto salaryDto = new SalaryDto();
		salaryDto.setEmployeeId(salary.getEmployeeId());
		salaryDto.setSalaryAmount(salary.getSalaryAmount());
		salaryDto.setBonus(salary.getBonus());
		return salaryDto;
		
	}

}
