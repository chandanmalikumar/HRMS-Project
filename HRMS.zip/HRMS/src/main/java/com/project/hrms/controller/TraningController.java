package com.project.hrms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.TraningDto;
import com.project.hrms.service.TraningService;

@RestController
public class TraningController {
	
	
	@Autowired
	TraningService traningService;
	
	
	@PostMapping("/traning")
	public ResponseEntity<TraningDto> saveTraning(@RequestBody TraningDto traningDto){
		traningService.saveTraning(traningDto);
		return new ResponseEntity<>(traningDto, HttpStatus.CREATED);
	}

}
