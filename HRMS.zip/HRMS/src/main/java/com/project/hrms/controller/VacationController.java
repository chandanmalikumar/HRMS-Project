package com.project.hrms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.project.hrms.dto.VacationDto;
import com.project.hrms.service.VacationService;

@RestController
public class VacationController {
	
	
	@Autowired
	VacationService vacationService;
	
	
	@PostMapping("/vacation")
	public ResponseEntity<VacationDto> SaveVacation(@RequestBody VacationDto vacationDto){
		vacationService.saveVacation(vacationDto);
		return new ResponseEntity<>(vacationDto, HttpStatus.CREATED);
		
	}
}
