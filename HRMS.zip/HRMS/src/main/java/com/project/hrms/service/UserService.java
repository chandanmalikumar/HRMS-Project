package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.UserRepository;
import com.project.hrms.dto.UserDto;
import com.project.hrms.entity.User;

@Service
public class UserService {
	
	@Autowired
	UserRepository userRepository;
	
	public void saveUser(UserDto userDto) {
		userRepository.save(userDtoTouser(userDto));
	}
	
	public User userDtoTouser(UserDto userDto) {
		User user = new User();
		
		user.setUserId(userDto.getUserId());
		user.setUserName(userDto.getUserName());
		user.setUserEmail(userDto.getUserEmail());
		user.setUserPassword(userDto.getUserPassword());
		user.setRoles(userDto.getRoles());
		return user;
	}
	
	public UserDto userToUserDto(User user) {
		UserDto userDto = new UserDto();
		
		userDto.setUserId(user.getUserId());
		userDto.setUserName(user.getUserName());
		userDto.setUserEmail(user.getUserEmail());
		userDto.setUserPassword(user.getUserPassword());
		userDto.setRoles(user.getRoles());
		return userDto;
		
	}
}
