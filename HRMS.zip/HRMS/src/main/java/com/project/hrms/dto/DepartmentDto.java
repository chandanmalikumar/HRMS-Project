package com.project.hrms.dto;

import javax.persistence.Id;

public class DepartmentDto {
	
	@Id
	private int employeeId;
	private String departmentTitle;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getDepartmentTitle() {
		return departmentTitle;
	}
	public void setDepartmentTitle(String departmentTitle) {
		this.departmentTitle = departmentTitle;
	}
	
	
	@Override
	public String toString() {
		return "DepartmentDto [employeeId=" + employeeId + ", departmentTitle=" + departmentTitle + "]";
	}
	
	

}
