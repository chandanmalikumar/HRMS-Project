package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.AttendanceRepository;
import com.project.hrms.dto.AttendanceDto;
import com.project.hrms.entity.Attendance;


@Service
public class AttendanceService {
	
	
	@Autowired
	AttendanceRepository attendanceRepository;
	
	public void saveAttendance(AttendanceDto attendanceDto) {
		attendanceRepository.save(attendanceDtoToAttendance(attendanceDto));
	}
	

	public Attendance attendanceDtoToAttendance(AttendanceDto attendanceDto) {
		Attendance attendance = new Attendance();
		attendance.setEmployeeId(attendanceDto.getEmployeeId());
		attendance.setAttendanceType(attendanceDto.getAttendanceType());
		attendance.setAttendanceDateTime(attendanceDto.getAttendanceDateTime());
		return attendance;
	}
	
	public AttendanceDto attendanceToAttendanceDto(Attendance attendance) {
		AttendanceDto attendanceDto = new AttendanceDto();
		attendanceDto.setEmployeeId(attendance.getEmployeeId());
		attendanceDto.setAttendanceType(attendance.getAttendanceType());
		attendanceDto.setAttendanceDateTime(attendance.getAttendanceDateTime());
		return attendanceDto;
		
	}
}
