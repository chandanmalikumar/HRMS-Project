package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.VacationRepository;
import com.project.hrms.dto.VacationDto;
import com.project.hrms.entity.Vacation;

@Service
public class VacationService {

	
	@Autowired
	VacationRepository vacationRepository;
	
	public void saveVacation(VacationDto vacationDto) {
		vacationRepository.save(vacationDtoToVacation(vacationDto));
	}
	
	public Vacation vacationDtoToVacation(VacationDto vacationDto) {
		Vacation vacation = new Vacation();
		
		vacation.setEmployeeId(vacationDto.getEmployeeId());
		vacation.setDateFrom(vacationDto.getDateFrom());
		vacation.setDateTo(vacationDto.getDateTo());
		vacation.setTitle(vacationDto.getTitle());
		return vacation;
	}
	
	public VacationDto vacationToVacationDto(Vacation vacation) {
		VacationDto vacationDto = new VacationDto();
		
		vacationDto.setEmployeeId(vacation.getEmployeeId());
		vacationDto.setDateFrom(vacation.getDateFrom());
		vacationDto.setDateTo(vacation.getDateTo());
		vacationDto.setTitle(vacation.getTitle());
		return vacationDto;
		
	}
}
