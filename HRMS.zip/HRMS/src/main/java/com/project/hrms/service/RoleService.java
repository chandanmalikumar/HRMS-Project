package com.project.hrms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.hrms.dao.RoleRepository;
import com.project.hrms.dto.RoleDto;
import com.project.hrms.entity.Role;

@Service
public class RoleService {
	
	@Autowired
	RoleRepository roleRepository;
	
	public void saveRole(RoleDto roleDto) {
		roleRepository.save(roleDtoToRole(roleDto));
	}
	
	public Role roleDtoToRole(RoleDto roleDto) {
		Role role = new Role();
		
		role.setRoleId(roleDto.getRoleId());
		role.setRoleName(roleDto.getRoleName());
		return role;
	}
	
	public RoleDto roleToRoleDto(Role role) {
		RoleDto roleDto = new RoleDto();
		
		roleDto.setRoleId(role.getRoleId());
		roleDto.setRoleName(role.getRoleName());
		return roleDto;
		
	}

}
