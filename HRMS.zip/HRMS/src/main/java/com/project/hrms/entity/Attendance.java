package com.project.hrms.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="attendance")
public class Attendance {
	
	@Id
	private int employeeId;
	private String attendanceType;
	private String attendanceDateTime;
	
	
	public int getEmployeeId() {
		return employeeId;
	}
	public void setEmployeeId(int employeeId) {
		this.employeeId = employeeId;
	}
	public String getAttendanceType() {
		return attendanceType;
	}
	public void setAttendanceType(String attendanceType) {
		this.attendanceType = attendanceType;
	}
	public String getAttendanceDateTime() {
		return attendanceDateTime;
	}
	public void setAttendanceDateTime(String attendanceDateTime) {
		this.attendanceDateTime = attendanceDateTime;
	}
	
	
	@Override
	public String toString() {
		return "Attendance [employeeId=" + employeeId + ", attendanceType=" + attendanceType + ", attendanceDateTime="
				+ attendanceDateTime + "]";
	}
	
	

}
